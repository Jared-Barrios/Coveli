(function(){
    const body = document.querySelector('body');
    body.classList.add('text-center');
})();