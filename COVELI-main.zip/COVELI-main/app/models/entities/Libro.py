class Libro():

    def __init__(self, isbn, titulo, autor, anoedicion, precio):
        self.isbn = isbn
        self.titulo = titulo
        self.autor = autor
        self.anoedicion = anoedicion
        self.precio = precio
        self.unidades_vendidas = 0