LOGIN_CREDENCIALESINVALIDAS = ' Usuario o password incorrectos'
LOGOUT = 'Cerraste sesión exitosamente'

MENSAJE_BIENVENIDA = ' Bienvenido(a) a la libreria "COVELI" '

USUARIO_CREADO = 'El usuario se creo correctamente'
USUARIO_ERROR = 'Lo siento, no se pudo crear al usuario'